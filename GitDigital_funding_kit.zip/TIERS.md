# Sponsorship Tiers

## ☕ Coffee Supporter – $5/month
Basic support to keep development going.

## 🚀 Builder – $25/month
Supports new features and improvements.

## 🧠 Innovator – $100/month
Helps fund major roadmap items.

## 🏆 Founding Sponsor – $500+/month
Top-tier supporters helping drive the vision.
