# RickCreator87 Funding Kit

This folder contains reusable funding and sponsor configuration files.

Files included:

- SUPPORT.md – explains how people can support the project
- FUNDING.yml – GitHub Sponsors configuration
- SPONSORS.md – sponsor recognition page
- TIERS.md – sponsorship tiers

You can drop these files into any repository to enable funding links and sponsorship visibility.
