
# Tinkerflow GitHub App

This GitHub App runs deterministic Tinkerflow governance checks on pull requests.

## Setup

1. Create a GitHub App at https://github.com/settings/apps
2. Set webhook URL to your deployed server
3. Add APP_ID, PRIVATE_KEY, and WEBHOOK_SECRET to .env
4. npm install
5. npm run dev

The app listens for pull_request events and posts governance trace results as PR comments.
