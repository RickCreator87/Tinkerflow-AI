
import { Octokit } from "@octokit/rest";
import { runTinkerflow } from "../lib/tinkerflow-runner";

export async function handlePullRequest(octokit: Octokit, payload: any) {
  const { repository, pull_request } = payload;
  const owner = repository.owner.login;
  const repo = repository.name;
  const prNumber = pull_request.number;

  const trace = await runTinkerflow();

  const summary = `
## 🔍 Tinkerflow Governance Check

**Flow ID:** ${trace.flowId}
**Status:** ${trace.status}

### Step Results
${trace.steps.map((s:any) => `- ${s.step}: ${s.status}`).join("\n")}
`;

  await octokit.issues.createComment({
    owner,
    repo,
    issue_number: prNumber,
    body: summary
  });
}
