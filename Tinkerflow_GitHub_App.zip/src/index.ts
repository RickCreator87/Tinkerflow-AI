
import dotenv from "dotenv";
import { App } from "@octokit/app";
import { createNodeMiddleware } from "@octokit/webhooks";
import http from "http";
import { handlePullRequest } from "./handlers/pull-request";

dotenv.config();

const app = new App({
  appId: process.env.APP_ID!,
  privateKey: process.env.PRIVATE_KEY!,
  webhooks: {
    secret: process.env.WEBHOOK_SECRET!
  }
});

app.webhooks.on("pull_request.opened", async ({ octokit, payload }) => {
  await handlePullRequest(octokit, payload);
});

const middleware = createNodeMiddleware(app.webhooks);

http.createServer(middleware).listen(3000, () => {
  console.log("Tinkerflow GitHub App running on port 3000");
});
