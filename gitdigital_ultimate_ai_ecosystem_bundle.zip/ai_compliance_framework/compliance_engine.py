
class ComplianceEngine:

    def evaluate(self, artifact, rules):
        issues = []

        for rule in rules:
            if rule["pattern"] in artifact:
                issues.append(rule["name"])

        return issues
