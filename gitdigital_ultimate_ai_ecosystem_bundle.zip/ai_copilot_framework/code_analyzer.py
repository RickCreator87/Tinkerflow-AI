
class CodeAnalyzer:

    def suggest(self, code):
        suggestions = []

        if "print(" in code:
            suggestions.append("Use logging instead of print.")

        if "TODO" in code:
            suggestions.append("Resolve TODO items.")

        return suggestions
