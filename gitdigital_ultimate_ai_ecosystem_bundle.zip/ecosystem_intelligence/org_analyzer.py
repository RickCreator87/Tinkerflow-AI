
import os

class EcosystemAnalyzer:

    def scan(self, root):
        repos = []
        for name in os.listdir(root):
            if os.path.isdir(os.path.join(root, name)):
                repos.append(name)
        return repos
