
Frontend Dashboard

Suggested stack:
- Next.js
- Tailwind
- Graph visualization (D3)

Features:
- repo health
- AI suggestions
- compliance alerts
- architecture graphs
