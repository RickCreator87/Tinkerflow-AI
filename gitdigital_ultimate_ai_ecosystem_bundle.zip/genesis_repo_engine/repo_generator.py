
import shutil

class RepoGenerator:

    def create_repo(self, template_path, name):
        shutil.copytree(template_path, name)
        print("Repo created:", name)
