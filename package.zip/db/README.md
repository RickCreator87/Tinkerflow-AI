# PostgreSQL Database Integration for Railway

A production-ready PostgreSQL integration layer for Node.js applications deployed on Railway.

## Project Structure

```
db/
├── db.js              # Database connection pool
├── test-db.js         # Connection test script
├── schema.sql         # Complete database schema
├── migrations/        # Database migrations
│   ├── 001_init.sql
│   ├── 002_users.sql
│   ├── 003_badges.sql
│   └── 004_user_badges.sql
├── queries/           # Query modules
│   ├── users.js
│   ├── badges.js
│   └── userBadges.js
└── README.md
```

## Setup

### 1. Install Dependencies

Ensure you have the `pg` package installed in your project:

```bash
npm install pg
```

### 2. Configure Environment Variable

Set the `DATABASE_URL` environment variable in your Railway project settings or local `.env` file:

```
DATABASE_URL=postgresql://username:password@host:port/database
```

## Running Migrations

### Option 1: Run Individual Migration Files

Execute each migration file in order using `psql` or a database client:

```bash
psql $DATABASE_URL -f migrations/001_init.sql
psql $DATABASE_URL -f migrations/002_users.sql
psql $DATABASE_URL -f migrations/003_badges.sql
psql $DATABASE_URL -f migrations/004_user_badges.sql
```

### Option 2: Run Complete Schema

Alternatively, run the complete schema file:

```bash
psql $DATABASE_URL -f schema.sql
```

### Option 3: Programmatic Migrations

You can create a migration runner script that executes the SQL files programmatically using the pool.

## Testing the Connection

Run the test script to verify your database connection:

```bash
node test-db.js
```

Expected output on success:
```
Database connection successful: 2026-03-26T07:24:53.000Z
```

Expected output on failure:
```
Database connection failed: <error message>
```

## Using the Query Modules

All query modules use async/await patterns and parameterized SQL queries to prevent SQL injection attacks.

### Users Module

```javascript
import { createUser, getUserByEmail, listUsers, getUserById, deleteUser } from './queries/users.js';

// Create a new user
const user = await createUser('user@example.com');

// Get user by email
const existingUser = await getUserByEmail('user@example.com');

// List all users with pagination
const users = await listUsers(10, 0); // limit 10, offset 0

// Get user by ID
const userById = await getUserById('uuid-here');

// Delete a user
const deleted = await deleteUser('uuid-here');
```

### Badges Module

```javascript
import { createBadge, getBadgeById, getBadgeByName, listBadges, updateBadge, deleteBadge } from './queries/badges.js';

// Create a new badge
const badge = await createBadge('First Login', 'Awarded for first login');

// Get badge by ID
const badgeById = await getBadgeById('uuid-here');

// Get badge by name
const badgeByName = await getBadgeByName('First Login');

// List all badges
const badges = await listBadges();

// Update a badge
const updated = await updateBadge('uuid-here', { name: 'Updated Name' });

// Delete a badge
const deleted = await deleteBadge('uuid-here');
```

### User Badges Module

```javascript
import { awardBadge, userHasBadge, listBadgesForUser, listUsersWithBadge, revokeBadge, getBadgeCountForUser } from './queries/userBadges.js';

// Award a badge to a user
const userBadge = await awardBadge('user-uuid', 'badge-uuid');

// Check if user has a badge
const hasBadge = await userHasBadge('user-uuid', 'badge-uuid');

// List all badges for a user
const userBadges = await listBadgesForUser('user-uuid');

// List all users with a specific badge
const badgeUsers = await listUsersWithBadge('badge-uuid');

// Revoke a badge from a user
const revoked = await revokeBadge('user-uuid', 'badge-uuid');

// Get count of badges for a user
const badgeCount = await getBadgeCountForUser('user-uuid');
```

## SSL Configuration

The database pool is configured with SSL enabled for secure connections. The `rejectUnauthorized: false` option is set to accommodate Railway's SSL certificates. For production environments, ensure your database connection string uses the proper SSL endpoint.

## Connection Pool Settings

The pool is configured with the following settings:

- `max: 20` - Maximum number of clients in the pool
- `idleTimeoutMillis: 30000` - Client idle timeout
- `connectionTimeoutMillis: 2000` - Connection establishment timeout

Adjust these values based on your application's traffic and Railway's resource limits.

## Error Handling

All query functions will throw errors that you should catch in your application code:

```javascript
try {
  const user = await createUser('user@example.com');
} catch (error) {
  console.error('Database error:', error.message);
  // Handle the error appropriately
}
```

## Production Considerations

1. **Connection Pooling**: The pool automatically manages connections. Ensure you call `pool.end()` when shutting down your application.

2. **Indexing**: Indexes are created automatically for frequently queried columns (email, foreign keys).

3. **UUID Primary Keys**: The schema uses UUIDs generated by the `uuid-ossp` extension for secure, non-sequential identifiers.

4. **Cascading Deletes**: The `user_badges` table uses `ON DELETE CASCADE` to automatically remove badge associations when users are deleted.

5. **Environment Variables**: Never commit your `DATABASE_URL` to version control. Use Railway's environment variable settings or a `.env` file (added to `.gitignore`).
