-- Migration 001: Initialize database extensions
-- Run this first to enable UUID generation

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Verify the extension was created
SELECT extname, extversion FROM pg_extension WHERE extname = 'uuid-ossp';
