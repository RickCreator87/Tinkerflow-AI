-- Migration 003: Create badges table

CREATE TABLE IF NOT EXISTS badges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(100) NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create index on badge name for faster lookups
CREATE INDEX IF NOT EXISTS idx_badges_name ON badges(name);

-- Add comments for documentation
COMMENT ON TABLE badges IS 'Stores available badges that can be awarded to users';
COMMENT ON COLUMN badges.name IS 'Badge display name';
COMMENT ON COLUMN badges.description IS 'Detailed description of the badge';
