-- Migration 004: Create user_badges junction table

CREATE TABLE IF NOT EXISTS user_badges (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  badge_id UUID NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
  awarded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, badge_id)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_user_badges_user_id ON user_badges(user_id);
CREATE INDEX IF NOT EXISTS idx_user_badges_badge_id ON user_badges(badge_id);

-- Add comments for documentation
COMMENT ON TABLE user_badges IS 'Junction table linking users to their awarded badges';
COMMENT ON COLUMN user_badges.user_id IS 'Reference to the user who received the badge';
COMMENT ON COLUMN user_badges.badge_id IS 'Reference to the badge that was awarded';
COMMENT ON COLUMN user_badges.awarded_at IS 'Timestamp when the badge was awarded';
