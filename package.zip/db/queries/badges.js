import pool from '../db.js';

/**
 * Create a new badge
 * @param {string} name - The badge name
 * @param {string} description - The badge description
 * @returns {Promise<Object>} The created badge object
 */
export async function createBadge(name, description = null) {
  const query = `
    INSERT INTO badges (name, description)
    VALUES ($1, $2)
    RETURNING id, name, description, created_at
  `;
  const values = [name, description];
  const result = await pool.query(query, values);
  return result.rows[0];
}

/**
 * Get a badge by its ID
 * @param {string} id - The badge UUID
 * @returns {Promise<Object|null>} The badge object or null if not found
 */
export async function getBadgeById(id) {
  const query = `
    SELECT id, name, description, created_at
    FROM badges
    WHERE id = $1
  `;
  const values = [id];
  const result = await pool.query(query, values);
  return result.rows[0] || null;
}

/**
 * Get a badge by its name
 * @param {string} name - The badge name
 * @returns {Promise<Object|null>} The badge object or null if not found
 */
export async function getBadgeByName(name) {
  const query = `
    SELECT id, name, description, created_at
    FROM badges
    WHERE name = $1
  `;
  const values = [name];
  const result = await pool.query(query, values);
  return result.rows[0] || null;
}

/**
 * List all badges with optional pagination
 * @param {number} limit - Maximum number of badges to return
 * @param {number} offset - Number of badges to skip
 * @returns {Promise<Array>} Array of badge objects
 */
export async function listBadges(limit = 100, offset = 0) {
  const query = `
    SELECT id, name, description, created_at
    FROM badges
    ORDER BY created_at DESC
    LIMIT $1 OFFSET $2
  `;
  const values = [limit, offset];
  const result = await pool.query(query, values);
  return result.rows;
}

/**
 * Update a badge
 * @param {string} id - The badge UUID
 * @param {Object} updates - The fields to update
 * @returns {Promise<Object|null>} The updated badge object or null if not found
 */
export async function updateBadge(id, updates) {
  const fields = [];
  const values = [];
  let paramIndex = 1;

  if (updates.name !== undefined) {
    fields.push(`name = $${paramIndex++}`);
    values.push(updates.name);
  }

  if (updates.description !== undefined) {
    fields.push(`description = $${paramIndex++}`);
    values.push(updates.description);
  }

  if (fields.length === 0) {
    return getBadgeById(id);
  }

  values.push(id);
  const query = `
    UPDATE badges
    SET ${fields.join(', ')}
    WHERE id = $${paramIndex}
    RETURNING id, name, description, created_at
  `;

  const result = await pool.query(query, values);
  return result.rows[0] || null;
}

/**
 * Delete a badge by its ID
 * @param {string} id - The badge UUID
 * @returns {Promise<boolean>} True if badge was deleted
 */
export async function deleteBadge(id) {
  const query = `
    DELETE FROM badges
    WHERE id = $1
    RETURNING id
  `;
  const values = [id];
  const result = await pool.query(query, values);
  return result.rowCount > 0;
}
