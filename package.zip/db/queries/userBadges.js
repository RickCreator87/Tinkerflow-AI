import pool from '../db.js';

/**
 * Award a badge to a user
 * @param {string} userId - The user's UUID
 * @param {string} badgeId - The badge UUID
 * @returns {Promise<Object>} The created user_badge record
 */
export async function awardBadge(userId, badgeId) {
  const query = `
    INSERT INTO user_badges (user_id, badge_id)
    VALUES ($1, $2)
    ON CONFLICT (user_id, badge_id) DO NOTHING
    RETURNING user_id, badge_id, awarded_at
  `;
  const values = [userId, badgeId];
  const result = await pool.query(query, values);
  return result.rows[0] || null;
}

/**
 * Check if a user has a specific badge
 * @param {string} userId - The user's UUID
 * @param {string} badgeId - The badge UUID
 * @returns {Promise<boolean>} True if user has the badge
 */
export async function userHasBadge(userId, badgeId) {
  const query = `
    SELECT 1 FROM user_badges
    WHERE user_id = $1 AND badge_id = $2
  `;
  const values = [userId, badgeId];
  const result = await pool.query(query, values);
  return result.rowCount > 0;
}

/**
 * List all badges for a specific user
 * @param {string} userId - The user's UUID
 * @returns {Promise<Array>} Array of badge objects with award timestamp
 */
export async function listBadgesForUser(userId) {
  const query = `
    SELECT 
      b.id,
      b.name,
      b.description,
      ub.awarded_at
    FROM user_badges ub
    JOIN badges b ON ub.badge_id = b.id
    WHERE ub.user_id = $1
    ORDER BY ub.awarded_at DESC
  `;
  const values = [userId];
  const result = await pool.query(query, values);
  return result.rows;
}

/**
 * List all users who have a specific badge
 * @param {string} badgeId - The badge UUID
 * @returns {Promise<Array>} Array of user objects with award timestamp
 */
export async function listUsersWithBadge(badgeId) {
  const query = `
    SELECT 
      u.id,
      u.email,
      ub.awarded_at
    FROM user_badges ub
    JOIN users u ON ub.user_id = u.id
    WHERE ub.badge_id = $1
    ORDER BY ub.awarded_at DESC
  `;
  const values = [badgeId];
  const result = await pool.query(query, values);
  return result.rows;
}

/**
 * Revoke a badge from a user
 * @param {string} userId - The user's UUID
 * @param {string} badgeId - The badge UUID
 * @returns {Promise<boolean>} True if badge was revoked
 */
export async function revokeBadge(userId, badgeId) {
  const query = `
    DELETE FROM user_badges
    WHERE user_id = $1 AND badge_id = $2
    RETURNING user_id
  `;
  const values = [userId, badgeId];
  const result = await pool.query(query, values);
  return result.rowCount > 0;
}

/**
 * Get the count of badges for a user
 * @param {string} userId - The user's UUID
 * @returns {Promise<number>} The number of badges the user has
 */
export async function getBadgeCountForUser(userId) {
  const query = `
    SELECT COUNT(*) as count
    FROM user_badges
    WHERE user_id = $1
  `;
  const values = [userId];
  const result = await pool.query(query, values);
  return parseInt(result.rows[0].count, 10);
}
