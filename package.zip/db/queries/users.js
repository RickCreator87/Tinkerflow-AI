import pool from '../db.js';

/**
 * Create a new user with the provided email
 * @param {string} email - The user's email address
 * @returns {Promise<Object>} The created user object
 */
export async function createUser(email) {
  const query = `
    INSERT INTO users (email)
    VALUES ($1)
    RETURNING id, email, created_at
  `;
  const values = [email];
  const result = await pool.query(query, values);
  return result.rows[0];
}

/**
 * Get a user by their email address
 * @param {string} email - The user's email address
 * @returns {Promise<Object|null>} The user object or null if not found
 */
export async function getUserByEmail(email) {
  const query = `
    SELECT id, email, created_at
    FROM users
    WHERE email = $1
  `;
  const values = [email];
  const result = await pool.query(query, values);
  return result.rows[0] || null;
}

/**
 * Get a user by their ID
 * @param {string} id - The user's UUID
 * @returns {Promise<Object|null>} The user object or null if not found
 */
export async function getUserById(id) {
  const query = `
    SELECT id, email, created_at
    FROM users
    WHERE id = $1
  `;
  const values = [id];
  const result = await pool.query(query, values);
  return result.rows[0] || null;
}

/**
 * List all users with optional pagination
 * @param {number} limit - Maximum number of users to return
 * @param {number} offset - Number of users to skip
 * @returns {Promise<Array>} Array of user objects
 */
export async function listUsers(limit = 100, offset = 0) {
  const query = `
    SELECT id, email, created_at
    FROM users
    ORDER BY created_at DESC
    LIMIT $1 OFFSET $2
  `;
  const values = [limit, offset];
  const result = await pool.query(query, values);
  return result.rows;
}

/**
 * Delete a user by their ID
 * @param {string} id - The user's UUID
 * @returns {Promise<boolean>} True if user was deleted
 */
export async function deleteUser(id) {
  const query = `
    DELETE FROM users
    WHERE id = $1
    RETURNING id
  `;
  const values = [id];
  const result = await pool.query(query, values);
  return result.rowCount > 0;
}
