
# TinkerFlow AI SaaS

TinkerFlow is a modular AI assistant platform with multi‑model routing, tools, admin console, and owner bypass billing.

## Features
- Multi‑model AI routing
- Tool execution framework
- Owner/Admin role bypass (no billing)
- User accounts + usage tracking
- FastAPI backend
- Next.js frontend skeleton
- Admin dashboard
- Agent system scaffold

## Run Backend
pip install -r requirements.txt
uvicorn app.main:app --reload

## Run Frontend
cd frontend
npm install
npm run dev
