
def check_usage(user):
    if user.role in ["owner", "admin"]:
        return True

    if user.plan == "free" and user.usage > 100:
        return False

    user.usage += 1
    return True
