
from fastapi import FastAPI
from .routers import chat, admin

app = FastAPI(title="TinkerFlow AI API")

app.include_router(chat.router)
app.include_router(admin.router)

@app.get("/")
def root():
    return {"message": "TinkerFlow AI running"}
