
from fastapi import APIRouter

router = APIRouter(prefix="/admin")

@router.get("/stats")
def stats():
    return {
        "users": 120,
        "requests_today": 9821,
        "models_active": 4
    }
