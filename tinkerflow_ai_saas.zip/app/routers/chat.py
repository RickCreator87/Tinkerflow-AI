
from fastapi import APIRouter

router = APIRouter(prefix="/chat")

@router.post("/message")
def chat(message: str):
    return {
        "response": f"Simulated AI response to: {message}"
    }
