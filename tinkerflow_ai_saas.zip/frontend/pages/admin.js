
export default function Admin() {
  return (
    <div style={{fontFamily:"sans-serif",padding:"40px"}}>
      <h1>Owner Console</h1>
      <p>System metrics and controls appear here.</p>
    </div>
  )
}
