
export default function Home() {
  return (
    <div style={{fontFamily:"sans-serif",padding:"40px"}}>
      <h1>TinkerFlow AI</h1>
      <p>Your AI command center is running.</p>
    </div>
  )
}
