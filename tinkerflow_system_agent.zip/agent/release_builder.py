
import os, zipfile, requests

def build_release_zip(repo):
    zip_url = repo.get_archive_link("zipball")
    response = requests.get(zip_url)

    filename = f"{repo.name}_release.zip"

    with open(filename, "wb") as f:
        f.write(response.content)

    return filename
