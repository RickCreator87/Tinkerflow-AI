
def scan_repository(repo):
    data = {
        "name": repo.name,
        "stars": repo.stargazers_count,
        "open_issues": repo.open_issues_count,
        "default_branch": repo.default_branch
    }

    try:
        repo.get_contents("README.md")
        data["has_readme"] = True
    except:
        data["has_readme"] = False

    try:
        repo.get_contents("LICENSE")
        data["has_license"] = True
    except:
        data["has_license"] = False

    return data
