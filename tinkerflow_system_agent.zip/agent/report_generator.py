
import json

def generate_report(scan_results, output_file="repo_report.json"):
    with open(output_file, "w") as f:
        json.dump(scan_results, f, indent=2)

    return output_file
