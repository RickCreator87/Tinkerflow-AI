
import schedule
import time

def run_daily(task):
    schedule.every().day.at("02:00").do(task)

    while True:
        schedule.run_pending()
        time.sleep(60)
