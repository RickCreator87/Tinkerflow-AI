
from github import Github
from .repo_scanner import scan_repository
from .release_builder import build_release_zip

class SystemAgent:

    def __init__(self, github_token, org_name):
        self.github = Github(github_token)
        self.org = self.github.get_organization(org_name)

    def scan_all_repos(self):
        results = []
        for repo in self.org.get_repos():
            results.append(scan_repository(repo))
        return results

    def package_repo(self, repo_name):
        repo = self.org.get_repo(repo_name)
        return build_release_zip(repo)
