
from agent.system_agent import SystemAgent
from agent.report_generator import generate_report

TOKEN = "YOUR_GITHUB_TOKEN"
ORG = "Gitdigital-products"

agent = SystemAgent(TOKEN, ORG)

results = agent.scan_all_repos()
report = generate_report(results)

print("Scan complete:", report)
