
# TinkerFlow Tool Engine

Expanded AI automation engine for the TinkerFlow assistant.

Includes:
- Tool plugin system
- File tools (zip / unzip / read / write)
- Vision tools (image analysis scaffold)
- Email + SMS automation
- GitHub integration scaffold
- Command palette system

Tools are registered dynamically so the AI can call them.
