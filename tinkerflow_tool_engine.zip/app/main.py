
from fastapi import FastAPI
from tools.registry import tool_registry

app = FastAPI(title="TinkerFlow Tool Engine")

@app.get("/tools")
def list_tools():
    return {"tools": list(tool_registry.keys())}
