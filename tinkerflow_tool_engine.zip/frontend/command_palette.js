
export const commands = [
  "/zip",
  "/unzip",
  "/read-file",
  "/write-file",
  "/send-sms",
  "/create-repo",
  "/extract-text"
]
