
export default function ToolPanel() {
  return (
    <div>
      <h2>Tools</h2>
      <ul>
        <li>File Tools</li>
        <li>Vision Tools</li>
        <li>Email & SMS</li>
        <li>GitHub Integration</li>
      </ul>
    </div>
  )
}
