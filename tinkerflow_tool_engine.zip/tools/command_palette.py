
from tools.registry import tool_registry

def run_command(command_name, *args, **kwargs):
    if command_name not in tool_registry:
        return "Command not found"

    return tool_registry[command_name](*args, **kwargs)
