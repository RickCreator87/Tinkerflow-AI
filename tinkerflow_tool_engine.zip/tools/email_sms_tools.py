
from twilio.rest import Client
from .registry import register_tool

def send_sms(account_sid, auth_token, from_number, to_number, message):
    client = Client(account_sid, auth_token)
    client.messages.create(
        body=message,
        from_=from_number,
        to=to_number
    )

register_tool("send_sms", send_sms)
