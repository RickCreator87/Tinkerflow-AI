
import zipfile, os
from .registry import register_tool

def zip_folder(folder_path, output_file):
    with zipfile.ZipFile(output_file, 'w') as z:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                z.write(os.path.join(root, file))

def unzip_file(zip_path, extract_to):
    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(extract_to)

def read_file(path):
    with open(path) as f:
        return f.read()

def write_file(path, content):
    with open(path, "w") as f:
        f.write(content)

register_tool("zip_folder", zip_folder)
register_tool("unzip_file", unzip_file)
register_tool("read_file", read_file)
register_tool("write_file", write_file)
