
from github import Github
from .registry import register_tool

def create_repo(token, name):
    g = Github(token)
    user = g.get_user()
    repo = user.create_repo(name)
    return repo.html_url

register_tool("create_repo", create_repo)
