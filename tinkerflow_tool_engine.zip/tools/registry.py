
tool_registry = {}

def register_tool(name, func):
    tool_registry[name] = func
