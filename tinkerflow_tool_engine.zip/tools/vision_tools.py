
import cv2
import pytesseract
from PIL import Image
from .registry import register_tool

def extract_text(image_path):
    img = cv2.imread(image_path)
    text = pytesseract.image_to_string(img)
    return text

register_tool("extract_text", extract_text)
