# Buy Me a Coffee

If you like this project and want to support future development,
you can buy the developer a coffee.

☕ Support here:
https://buymeacoffee.com/RickCreator87

Every coffee helps fund:
- Development time
- Infrastructure
- New open-source tools