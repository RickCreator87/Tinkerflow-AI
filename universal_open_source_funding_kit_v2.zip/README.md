# Universal Open Source Funding Kit

This kit lets you drop funding support into any repository instantly.

Supported platforms:
- GitHub Sponsors
- Buy Me a Coffee
- Patreon
- Crypto donations

Place `.github/FUNDING.yml` in your repo or in a global `.github` repository
to automatically enable the Sponsor button across projects.