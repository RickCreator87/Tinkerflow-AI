# Support This Project

If this project helped you, consider supporting development.

## Funding Options

GitHub Sponsors:
https://github.com/sponsors/RickCreator87

Buy Me a Coffee:
https://buymeacoffee.com/RickCreator87

Patreon:
https://patreon.com/RickCreator87

Crypto:
BTC: YOUR_BITCOIN_ADDRESS
ETH: YOUR_ETH_ADDRESS
SOL: YOUR_SOL_ADDRESS